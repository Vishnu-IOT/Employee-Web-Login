import React, { useState } from 'react';
import { MdKeyboardArrowLeft } from 'react-icons/md';
import animationData from '../lottie/Online Work.json';
import Lottie from 'lottie-react';
import { useNavigate } from 'react-router-dom';

function LateDays() {
const navigate = useNavigate();

  const now = new Date();
  const currentMonth = String(now.getMonth() + 1);
  const currentYear = now.getFullYear();

  const [dateFilter, setDateFilter] = useState({
    user_id: '',
    month: currentMonth,
    year: currentYear,
  });

  const monthOptions = [
    { label: 'January', value: '1' },
    { label: 'February', value: '2' },
    { label: 'March', value: '3' },
    { label: 'April', value: '4' },
    { label: 'May', value: '5' },
    { label: 'June', value: '6' },
    { label: 'July', value: '7' },
    { label: 'August', value: '8' },
    { label: 'September', value: '9' },
    { label: 'October', value: '10' },
    { label: 'November', value: '11' },
    { label: 'December', value: '12' },
  ];

  const handleDate = (e) => {
    const { name, value } = e.target;

    setDateFilter((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <>
      <div className="permission-screen">
        <div className="report-top">
          <div className="report-back">
            <button className="down-btn" onClick={() => navigate('/home')}>
              <MdKeyboardArrowLeft />
            </button>
            <h3 style={{ fontWeight: 600 }}>MyKonnect</h3>
          </div>
          <div className="permission-main">
            <div className="page-headers glass-panels">
              <div className="header-content">
                <div className="permission-title-groups">
                  <Lottie
                    animationData={animationData}
                    style={{ width: 100, height: 100 }}
                  />
                  <div>
                    <h2>Late Days List</h2>
                    <p>
                      Track and manage employee late entries, ensuring better
                      visibility into attendance patterns and punctuality.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div
              style={{
                display: 'flex',
                width: '100%',
                gap: '10px',
                padding: '16px 0',
              }}
            >
              <div className="form-group">
                <select
                  name="month"
                  value={dateFilter.month}
                  onChange={handleDate}
                >
                  {monthOptions.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <select
                  name="year"
                  value={dateFilter.year}
                  onChange={handleDate}
                >
                  {[2026, 2025, 2024, 2023].map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="permission-history">
              <h4>Late Days List</h4>
            </div>

            <div className="permission-title-group">
              <Lottie
                animationData={animationData}
                loop={true}
                style={{ width: 120, height: 120 }}
              />
              <div>
                <p>No Late Days Found</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default LateDays;
