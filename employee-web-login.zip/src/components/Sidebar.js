// ===== SIDEBAR =====
import React from 'react';
import { BsPerson, BsSuitcase, BsSuitcase2 } from 'react-icons/bs';
import { FiLogOut } from 'react-icons/fi';
import { HiOutlineDocumentReport } from 'react-icons/hi';
import { IoCalendarOutline, IoHomeOutline } from 'react-icons/io5';
import { LuTicketCheck } from 'react-icons/lu';
import { PiScroll } from 'react-icons/pi';
import { useLocation, useNavigate } from 'react-router-dom';

function Sidebar({ setUser }) {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };
  const items = [
    { label: 'Home', tab: '/home', icon: <IoHomeOutline /> },
    { label: 'Attendance', tab: '/attendance', icon: <IoCalendarOutline /> },
    {
      label: 'Monthly Report',
      tab: '/report',
      icon: <HiOutlineDocumentReport />,
    },
    { label: 'Permission', tab: '/permission', icon: <BsPerson /> },
    { label: 'Leave', tab: '/leave', icon: <BsSuitcase2 /> },
    { label: 'Raise Ticket', tab: '/ticket', icon: <LuTicketCheck /> },
    { label: 'Holidays', tab: '/holiday', icon: <BsSuitcase /> },
    { label: 'Late Days', tab: '/late', icon: <PiScroll /> },
    { label: 'Profile', tab: '/profile', icon: <BsPerson /> },
  ];
  return (
    <div className="desktop-sidebar">
      <div className="sidebar-logo">
        <div className="sidebar-logo-box">MK</div>
        <span>MyKonnect</span>
      </div>
      {items.map((item) => (
        <div
          key={item.tab}
          className={`sidebar-nav-item ${location.pathname === item.tab ? 'active' : ''}`}
          onClick={() => navigate(item.tab)}
        >
          {item.icon}
          {item.label}
        </div>
      ))}
      <div className="sidebar-logout" onClick={handleLogout}>
        <span>
          <FiLogOut />
        </span>
        <span>Logout</span>
      </div>
    </div>
  );
}

export default Sidebar;
