import { useEffect, useState } from 'react';
import MobileNav from './mobilenav';
import BottomNav from './BottomNav';
import {
  fetchAttendanceWMAPI,
  fetchHomePageAPI,
  storeMarkAttendanceAPI,
} from '../helper.js/api';

// ===== OVERVIEW SCREEN =====
export const OverviewScreen = () => {
  const [period, setPeriod] = useState('1M');
  const [wm, setWM] = useState('month');
  const [attendanceData, setAttendanceData] = useState([]);
  const [homeData, setHomeData] = useState(null);
  const [time, setTime] = useState(new Date());

  const [actionType, setActionType] = useState('');
  const [actionTime, setActionTime] = useState(null);
  const [checkData, setCheckData] = useState({
    type: '',
    checkin_lat: '',
    checkin_lon: '',
    checkout_lat: '',
    checkout_lon: '',
  });

  const [openDialog, setOpenDialog] = useState(false);

  const reversedData = [...attendanceData].reverse();

  useEffect(() => {
    async function overview() {
      const data = await fetchAttendanceWMAPI(wm);
      const data2 = await fetchHomePageAPI();
      setHomeData(data2);
      setAttendanceData(Array.isArray(data?.attendance) ? data.attendance : []);
    }
    overview();
  }, [wm]);

  const isValidTime = (time) => {
    return (
      time && time !== '--:--' && time !== '-:--:--' && time !== '--:--:--'
    );
  };

  const calculateWorkHours = (checkIn, checkOut) => {
    if (!isValidTime(checkIn) || !isValidTime(checkOut)) {
      return '-:--:--';
    }

    const inTime = new Date(`1970-01-01T${checkIn}`);
    const outTime = new Date(`1970-01-01T${checkOut}`);

    if (isNaN(inTime) || isNaN(outTime)) return '--:--';

    const diffMs = outTime - inTime;

    if (diffMs <= 0) return '--:--';

    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}`;
  };

  const formatTo12Hour = (timeStr) => {
    if (!timeStr || timeStr === '-:--:--') return '-:--:--';

    const date = new Date(`1970-01-01T${timeStr}`);

    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit', // ✅ include seconds
      hour12: true,
    });
  };

  const isCheckedIn = isValidTime(homeData?.attendance?.check_in?.time);
  const isCheckedOut = isValidTime(homeData?.attendance?.check_out?.time);

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const fmt = (d) =>
    d.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  const fmtDate = (d) =>
    d.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });

  const handleAction = (type) => {
    const now = new Date();
    setActionTime(now);
    setActionType(type);

    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude, longitude } = pos.coords;

      let updatedData = { ...checkData };

      if (type === 'checkin') {
        updatedData = {
          ...updatedData,
          type: 'checkin',
          checkin_lat: latitude,
          checkin_lon: longitude,
        };
      }

      if (type === 'checkout') {
        updatedData = {
          ...updatedData,
          type: 'checkout',
          checkout_lat: latitude,
          checkout_lon: longitude,
        };
      }
      if (type === 'break') {
        updatedData = {
          ...updatedData,
          type: 'break',
        };
      }

      setCheckData(updatedData);
      setOpenDialog(true);
    });
  };

  const handleAttendance = async () => {
    const formData = new FormData();

    Object.keys(checkData).forEach((key) => {
      if (
        checkData[key] !== '' &&
        checkData[key] !== null &&
        checkData[key] !== undefined
      ) {
        formData.append(key, checkData[key]);
      }
    });
    await storeMarkAttendanceAPI(formData);
    setOpenDialog(false);
  };

  return (
    <>
      <MobileNav />
      <div className="overview-screen">
        {/* Today's Overview Section */}
        <div className="section-title" style={{ padding: '8px 16px 0' }}>
          Today's Overview
        </div>
        <div>
          <div
            className="overview-title"
            style={{
              background: 'rgb(31, 82, 196)',
              borderRadius: '16px',
              padding: '16px',
              boxShadow: 'var(--shadow-lg)',
              position: 'relative',
              zIndex: 5,
              marginBottom: '0',
            }}
          >
            <div className="overview-top">
              <span className="overview-date">{fmtDate(time)}</span>
              <div className="live-badge">
                <div className="live-dot" />
                {fmt(time)}
              </div>
            </div>
            <div className="checkinout-row">
              <div className="checkinout-col">
                <span>Check In</span>
                <strong>{homeData?.attendance?.check_in?.time}</strong>
              </div>
              <div className="checkinout-divider" />
              <div className="checkinout-col">
                <span>Check Out</span>
                <strong>{homeData?.attendance?.check_out?.time}</strong>
              </div>
            </div>

            {!isCheckedIn ? (
              <button
                className="checkin-btn"
                onClick={() => handleAction('checkin')}
              >
                Check In
              </button>
            ) : isCheckedIn && !isCheckedOut ? (
              <div className="checkin-actions">
                <button
                  className="break-btn"
                  onClick={() => handleAction('break')}
                >
                  Take Break
                </button>
                <button
                  className="checkin-btn"
                  onClick={() => handleAction('checkout')}
                >
                  Check Out
                </button>
              </div>
            ) : (
              <button className="checkin-btn" disabled>
                Completed
              </button>
            )}
          </div>
        </div>

        {/* Check In Overview */}
        {openDialog && (
          <div className="dialog-overlay" onClick={() => setOpenDialog(false)}>
            <div className="dialog-box" onClick={(e) => e.stopPropagation()}>
              <h2 className="dialog-title">
                {actionType === 'checkin'
                  ? 'Ready to start your day? 🚀'
                  : actionType === 'break'
                    ? 'Break time! Relax a bit ☕'
                    : 'Time to relax, see you tomorrow 😊'}
              </h2>

              <div className="dialog-content">
                <div className="dialog-row">
                  <span className="icon">🕒</span>
                  <span>{fmt(actionTime)}</span>
                </div>

                <div className="dialog-row">
                  <span className="icon">📅</span>
                  <span>{fmtDate(time)}</span>
                </div>

                <div className="dialog-row">
                  <span className="icon">📍</span>
                  <span>54, Salem, Tamil Nadu, India</span>
                </div>
              </div>

              <button className="submit-btn" onClick={handleAttendance}>
                {actionType === 'checkin'
                  ? 'Submit Check-In'
                  : actionType === 'break'
                    ? 'Submit Break'
                    : 'Submit Check-Out'}
              </button>
            </div>
          </div>
        )}

        {/* Attendance Overview */}
        <div className="attendance-row-header" style={{ marginTop: 20 }}>
          <span className="section-title" style={{ margin: 0 }}>
            Attendance Overview
          </span>
          <div className="period-tabs">
            <button
              className={`period-tab ${period === '1W' ? 'active' : ''}`}
              onClick={() => {
                setPeriod('1W');
                setWM('week');
              }}
            >
              1W
            </button>

            <button
              className={`period-tab ${period === '1M' ? 'active' : ''}`}
              onClick={() => {
                setPeriod('1M');
                setWM('month');
              }}
            >
              1M
            </button>
          </div>
        </div>
        {/* Log Items */}
        <div style={{ display: 'flex', gap: '10px', flexDirection: 'column' }}>
          {reversedData?.map((log, i) => (
            <div className="attendance-log-item" key={i}>
              <div className="log-date-row">
                <span>{log.date}</span>
                <div
                  className={`badge ${
                    log.late_checkin
                      ? 'lates'
                      : log.type === 'PRESENT'
                        ? 'presents'
                        : 'absent'
                  }`}
                >
                  {log.late_checkin
                    ? `Late ${log.late_checkin_time}`
                    : log.type}
                </div>
              </div>
              <div className="log-times">
                <div className="log-time-col">
                  <span>Check in</span>
                  <strong>{formatTo12Hour(log.check_in)}</strong>
                </div>
                <div className="log-time-col">
                  <span>Check out</span>
                  <strong>{formatTo12Hour(log.check_out)}</strong>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Log Items */}
        {/* <h3 style={{ marginBottom: '16px', fontWeight: 800 }}>
          Attendance Overview
        </h3> */}
        <div className="desktop-attendance-table">
          <div className="desktop-table-header">
            <span>Date</span>
            <span>Check In</span>
            <span>Check Out</span>
            <span>Work Hours</span>
            <span>Status</span>
          </div>
          {reversedData?.map((log, i) => (
            <div className="desktop-table-row" key={i}>
              <span>{log.date}</span>
              <span>{formatTo12Hour(log.check_in)}</span>
              <span>{formatTo12Hour(log.check_out)}</span>
              <span>{calculateWorkHours(log.check_in, log.check_out)}</span>
              <span>
                <span className={`badge ${log.type}`}>{log.type}</span>
              </span>
            </div>
          ))}
        </div>
      </div>
      {/* Bottom nav — hidden on desktop via CSS */}
      <BottomNav />
    </>
  );
};
