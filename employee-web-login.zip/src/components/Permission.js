import React, { useState } from 'react';
import { MdAdd, MdKeyboardArrowLeft } from 'react-icons/md';
import animationData from '../lottie/Online Work.json';
import Lottie from 'lottie-react';
import { useNavigate } from 'react-router-dom';

function Permission() {
  const navigate = useNavigate();
  const [active, setActive] = useState('Total');

  return (
    <>
      <div className="permission-screen">
        <div className="report-top">
          <div className="report-back">
            <button className="down-btn" onClick={() => navigate('/home')}>
              <MdKeyboardArrowLeft />
            </button>
            <h3 style={{ fontWeight: 600 }}>MyKonnect</h3>
          </div>
          <div className="permission-main">
            <div className="page-headers glass-panels">
              <div className="header-content">
                <div className="permission-title-groups">
                  <Lottie
                    animationData={animationData}
                    style={{ width: 100, height: 100 }}
                  />
                  <div>
                    <h2>Permission History</h2>
                    <p>
                      Manage employee permission requests efficiently and
                      monitor their approval status in one centralized place.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="permission-history">
              <h4>Permission History</h4>
            </div>

            <div className="page-tabs">
              {['Total', 'Approved', 'Rejected', 'Pending'].map((tab) => (
                <button
                  key={tab}
                  className={`page-tab ${active === tab ? 'active' : ''}`}
                  onClick={() => setActive(tab)}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="permission-title-group">
              <Lottie
                animationData={animationData}
                loop={true}
                style={{ width: 120, height: 120 }}
              />
              <div>
                <p>No Permission Found</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="apply-main">
        <div className="apply-btn">
          <span style={{ fontSize: '18px' }}>
            <MdAdd />
          </span>{' '}
          <span>Apply Permission</span>
        </div>
      </div>
    </>
  );
}

export default Permission;
