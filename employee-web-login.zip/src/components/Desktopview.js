import { useEffect, useState } from 'react';
import { CgSandClock } from 'react-icons/cg';
import { FcBriefcase } from 'react-icons/fc';
import { LuCalendarCheck2 } from 'react-icons/lu';
import { MdOutlineCoffee } from 'react-icons/md';
import MonthlyReport from './MonthlyReport';

// ===== DESKTOP PANEL =====
export const DesktopPanel = ({ desktopTab, setDesktopTab }) => {
  const [users, setUsers] = useState();
  const [time, setTime] = useState(new Date());
  const [checkedIn, setCheckedIn] = useState(false);
  const [checkInTime, setCheckInTime] = useState(null);

  const handleCheckIn = () => {
    setCheckedIn(true);
    setCheckInTime(new Date());
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');

    if (storedUser) {
      setUsers(JSON.parse(storedUser));
    }
  }, []);

  const attendanceLogs = [
    {
      date: '15 Apr, 2026',
      checkIn: '--:--',
      checkOut: '--:--',
      status: 'absent',
      badge: 'Absent',
    },
    {
      date: '13 Apr, 2026',
      checkIn: '5:11:10 PM',
      checkOut: '7:39:44 PM',
      status: 'late',
      badge: 'Late 07:41',
    },
    {
      date: '12 Apr, 2026',
      checkIn: '9:02:00 AM',
      checkOut: '6:00:00 PM',
      status: 'present',
      badge: 'Present',
    },
    {
      date: '11 Apr, 2026',
      checkIn: '9:15:00 AM',
      checkOut: '6:30:00 PM',
      status: 'present',
      badge: 'Present',
    },
    {
      date: '10 Apr, 2026',
      checkIn: '9:00:00 AM',
      checkOut: '5:55:00 PM',
      status: 'present',
      badge: 'Present',
    },
  ];

  const fmt = (d) =>
    d.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  const fmtDate = (d) =>
    d.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });

  return (
    <div className="desktop-panel">
      <div className="desktop-head">
        <div>
          <h2>Welcome Back, Vishnu!</h2>
          <p className="sub">Employee Attendance & HR Management</p>
        </div>

        <div className="user-avatar-placeholder">M</div>
      </div>

      {/* <div className="page-tabs">
        {['Home', 'Attendance', 'Profile'].map((tab) => (
          <button
            key={tab}
            className={`page-tab ${desktopTab === tab ? 'active' : ''}`}
            onClick={() => setDesktopTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div> */}

      {desktopTab === 'Home' && (
        <>
          <div className="home-split">
            <div
              style={{
                background: '#346EF6',
                borderRadius: 'var(--radius-md)',
                padding: '20px',
                border: '1px solid var(--gray-light)',
                boxShadow: 'var(--shadow-sm)',
                width: '50%',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-around',
              }}
            >
              <div>
                <div className="overview-top">
                  <h3
                    style={{
                      marginBottom: '16px',
                      fontWeight: 800,
                      color: 'white',
                    }}
                  >
                    Today's Overview
                  </h3>
                  <div className="live-badge">
                    <div className="live-dot" />
                    {fmt(time)}
                  </div>
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '16px',
                  }}
                >
                  <div
                    style={{
                      background: '#eaf1ff43',
                      borderRadius: 'var(--radius-md)',
                      padding: '20px',
                      color: 'white',
                      textAlign: 'center',
                    }}
                  >
                    <div
                      style={{
                        fontSize: '0.85rem',
                        opacity: 0.8,
                        marginBottom: 6,
                      }}
                    >
                      Check In
                    </div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800 }}>
                      --:--
                    </div>
                  </div>
                  <div
                    style={{
                      background: '#eaf1ff2e',
                      borderRadius: 'var(--radius-md)',
                      padding: '20px',
                      color: 'white',
                      textAlign: 'center',
                    }}
                  >
                    <div
                      style={{
                        fontSize: '0.85rem',
                        opacity: 0.8,
                        marginBottom: 6,
                      }}
                    >
                      Check Out
                    </div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800 }}>
                      --:--
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <button className="checkin-desk" onClick={handleCheckIn}>
                  {checkedIn ? 'Checked In ✓' : 'Check In'}
                </button>
              </div>
            </div>

            <div className="desktop-cards-row2">
              <div className="desktop-stat-card">
                <div className="label">
                  <span style={{ color: 'var(--orange)', fontSize: '24px' }}>
                    <MdOutlineCoffee />
                  </span>
                </div>
                <div className="value">1</div>
                Break-In
              </div>
              <div className="desktop-stat-card">
                <div className="label">
                  <span style={{ color: '#8392A8', fontSize: '24px' }}>
                    <LuCalendarCheck2 />
                  </span>
                </div>
                <div className="value">0</div>
                Break-Out
              </div>
              <div className="desktop-stat-card">
                <div className="label">
                  <span style={{ color: 'var(--orange)', fontSize: '24px' }}>
                    <FcBriefcase />
                  </span>
                </div>
                <div className="value">07:41</div>
                Work Hours
              </div>
              <div className="desktop-stat-card">
                <div className="label">
                  <span style={{ color: '#360F00', fontSize: '24px' }}>
                    <CgSandClock />
                  </span>
                </div>
                <div className="value">07:41</div>
                Remaining Hours
              </div>
            </div>
          </div>

          <h3 style={{ marginBottom: '16px', fontWeight: 800 }}>
            Attendance Overview
          </h3>
          <div className="desktop-cards-row">
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--green)' }}>●</span> Present
              </div>
              <div className="value">1</div>
            </div>
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--red)' }}>●</span> Absent
              </div>
              <div className="value">0</div>
            </div>
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--orange)' }}>●</span> Permisssions
              </div>
              <div className="value">07:41</div>
            </div>
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--orange)' }}>●</span> Late Hrs
              </div>
              <div className="value">07:41</div>
            </div>
          </div>

          {/* <div className="desktop-cards-row">
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--orange)' }}>●</span> Break-In
              </div>
              <div className="value">1</div>
            </div>
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--orange)' }}>●</span> Break-Out
              </div>
              <div className="value">0</div>
            </div>
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--orange)' }}>●</span> Work Hours
              </div>
              <div className="value">07:41</div>
            </div>
            <div className="desktop-stat-card">
              <div className="label">
                <span style={{ color: 'var(--orange)' }}>●</span> Remaining
                Hours
              </div>
              <div className="value">07:41</div>
            </div>
          </div> */}

          {/* <div className="desktop-attendance-table">
            <div className="desktop-table-header">
              <span>Date</span>
              <span>Check In</span>
              <span>Check Out</span>
              <span>Work Hours</span>
              <span>Status</span>
            </div>
            {attendanceLogs.map((log, i) => (
              <div className="desktop-table-row" key={i}>
                <span>{log.date}</span>
                <span>{log.checkIn}</span>
                <span>{log.checkOut}</span>
                <span>{log.checkIn !== '--:--' ? '2h 28m' : '--'}</span>
                <span>
                  <span className={`badge ${log.status}`}>{log.badge}</span>
                </span>
              </div>
            ))}
          </div> */}
        </>
      )}

      {desktopTab === 'Attendance' && (
        <>
          <div
            style={{
              background: 'white',
              borderRadius: 'var(--radius-md)',
              padding: '20px',
              border: '1px solid var(--gray-light)',
              boxShadow: 'var(--shadow-sm)',
            }}
          >
            <div className="overview-top">
              {/* <span className="overview-date" style={{ color: 'black' }}>
                {fmtDate(time)}
              </span> */}
              <h3 style={{ marginBottom: '16px', fontWeight: 800 }}>
                Today's Overview — {fmtDate(time)}
              </h3>
              <div className="live-badge" style={{ color: 'black' }}>
                <div className="live-dot" />
                {fmt(time)}
              </div>
            </div>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: '16px',
              }}
            >
              <div
                style={{
                  background: 'var(--blue-primary)',
                  borderRadius: 'var(--radius-md)',
                  padding: '20px',
                  color: 'white',
                  textAlign: 'center',
                }}
              >
                <div
                  style={{ fontSize: '0.85rem', opacity: 0.8, marginBottom: 6 }}
                >
                  Check In
                </div>
                <div style={{ fontSize: '1.6rem', fontWeight: 800 }}>--:--</div>
              </div>
              <div
                style={{
                  background: 'var(--dark-card)',
                  borderRadius: 'var(--radius-md)',
                  padding: '20px',
                  color: 'white',
                  textAlign: 'center',
                }}
              >
                <div
                  style={{ fontSize: '0.85rem', opacity: 0.8, marginBottom: 6 }}
                >
                  Check Out
                </div>
                <div style={{ fontSize: '1.6rem', fontWeight: 800 }}>--:--</div>
              </div>
              <button className="checkin-btn" onClick={handleCheckIn}>
                {checkedIn ? 'Checked In ✓' : 'Check In'}
              </button>
            </div>
          </div>
          <h3 style={{ marginBottom: '16px', fontWeight: 800 }}>
            Attendance Overview
          </h3>
          <div className="desktop-attendance-table">
            <div className="desktop-table-header">
              <span>Date</span>
              <span>Check In</span>
              <span>Check Out</span>
              <span>Work Hours</span>
              <span>Status</span>
            </div>
            {attendanceLogs.map((log, i) => (
              <div className="desktop-table-row" key={i}>
                <span>{log.date}</span>
                <span>{log.checkIn}</span>
                <span>{log.checkOut}</span>
                <span>{log.checkIn !== '--:--' ? '2h 28m' : '--'}</span>
                <span>
                  <span className={`badge ${log.status}`}>{log.badge}</span>
                </span>
              </div>
            ))}
          </div>
        </>
      )}

      {desktopTab === 'Profile' && (
        <div className="desktop-profile-card">
          <div className="desktop-profile-avatar">M</div>
          <div className="desktop-profile-info">
            <h3>Mahalakshmi G</h3>
            <div className="role">Tally Editor · ID: 0031</div>
            <div className="desktop-info-grid">
              <div className="desktop-info-field">
                <label>Email</label>
                <span>mahalakshmiganesan2000@gmail.com</span>
              </div>
              <div className="desktop-info-field">
                <label>Phone</label>
                <span>7305326745</span>
              </div>
              <div className="desktop-info-field">
                <label>Location</label>
                <span>Salem</span>
              </div>
              <div className="desktop-info-field">
                <label>Company</label>
                <span>MPEOPLES</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {desktopTab === 'Report' && <MonthlyReport />}
    </div>
  );
};
