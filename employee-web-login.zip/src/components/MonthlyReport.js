import Lottie from 'lottie-react';
import React, { useState } from 'react';
import { IoMdArrowRoundBack, IoMdDownload } from 'react-icons/io';
import animationData from '../lottie/Online Work.json';
import { MdKeyboardArrowLeft } from 'react-icons/md';
import { useNavigate } from 'react-router-dom';

function MonthlyReport() {
  const navigate = useNavigate();

  const now = new Date();
  const currentMonth = String(now.getMonth() + 1);
  const currentYear = now.getFullYear();

  const [dateFilter, setDateFilter] = useState({
    user_id: '',
    month: currentMonth,
    year: currentYear,
  });

  const monthOptions = [
    { label: 'January', value: '1' },
    { label: 'February', value: '2' },
    { label: 'March', value: '3' },
    { label: 'April', value: '4' },
    { label: 'May', value: '5' },
    { label: 'June', value: '6' },
    { label: 'July', value: '7' },
    { label: 'August', value: '8' },
    { label: 'September', value: '9' },
    { label: 'October', value: '10' },
    { label: 'November', value: '11' },
    { label: 'December', value: '12' },
  ];

  const attendanceLogs = [
    {
      date: '15 Apr, 2026',
      checkIn: '--:--',
      checkOut: '--:--',
      status: 'absent',
      badge: 'Absent',
    },
    {
      date: '13 Apr, 2026',
      checkIn: '5:11:10 PM',
      checkOut: '7:39:44 PM',
      status: 'late',
      badge: 'Late 07:41',
    },
    {
      date: '12 Apr, 2026',
      checkIn: '9:02:00 AM',
      checkOut: '6:00:00 PM',
      status: 'present',
      badge: 'Present',
    },
    {
      date: '11 Apr, 2026',
      checkIn: '9:15:00 AM',
      checkOut: '6:30:00 PM',
      status: 'present',
      badge: 'Present',
    },
    {
      date: '10 Apr, 2026',
      checkIn: '9:00:00 AM',
      checkOut: '5:55:00 PM',
      status: 'present',
      badge: 'Present',
    },
  ];

  const handleDate = (e) => {
    const { name, value } = e.target;

    setDateFilter((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <div className="report-screen">
      <div className="report-top">
        <div className="report-back">
          <button className="down-btn" onClick={() => navigate('/home')}>
            <MdKeyboardArrowLeft />
          </button>
          <h3 style={{ fontWeight: 600 }}>Monthly Report</h3>
        </div>
        <div className="page-headers glass-panels">
          <div className="header-content">
            <div className="permission-title-groups">
              <Lottie
                animationData={animationData}
                style={{ width: 100, height: 100 }}
              />
              <div>
                <h2>Monthly Report</h2>
                <p>
                  Track and analyze monthly reports, ensuring clear insights
                  into employee performance and attendance across your
                  organization.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        style={{
          display: 'flex',
          width: '100%',
          gap: '10px',
          padding: '8px 16px',
        }}
      >
        <div className="form-group">
          <select name="month" value={dateFilter.month} onChange={handleDate}>
            {monthOptions.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <select name="year" value={dateFilter.year} onChange={handleDate}>
            {[2026, 2025, 2024, 2023].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <button className="excel-btn">
            <IoMdDownload />
          </button>
        </div>
      </div>
      {/* <h3 style={{ padding: '0 16px', fontWeight: 800 }}>Attendance Overview</h3> */}

      <div className="desktop-table">
        <div className="desktop-attendance-table">
          <div className="desktop-table-header">
            <span>Date</span>
            <span>Check In</span>
            <span>Check Out</span>
            <span>Work Hours</span>
            <span>Status</span>
          </div>
          {attendanceLogs.map((log, i) => (
            <div className="desktop-table-row" key={i}>
              <span>{log.date}</span>
              <span>{log.checkIn}</span>
              <span>{log.checkOut}</span>
              <span>{log.checkIn !== '--:--' ? '2h 28m' : '--'}</span>
              <span>
                <span className={`badge ${log.status}`}>{log.badge}</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="mobile-table">
        <div className="attendance-log-item">
          <div className="log-date-row">
            <span>13 Apr, 2026</span>
            <div className="badge-late">Late 07:41</div>
          </div>
          <div className="log-times">
            <div className="log-time-col">
              <span>Check in</span>
              <strong>5:11:10 PM</strong>
            </div>
            <div className="log-time-col">
              <span>Check out</span>
              <strong>7:39:44 PM</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MonthlyReport;
