import React, { useEffect, useState } from 'react';
import { FaPhoneAlt } from 'react-icons/fa';
import { IoMdHome } from 'react-icons/io';
import { MdWork } from 'react-icons/md';
import { RiMessage2Fill } from 'react-icons/ri';
import BottomNav from './BottomNav';
import { fetchProfileAPI } from '../helper.js/api';

function ProfileScreen({ setUser }) {
  const [users, setUsers] = useState(null);

  useEffect(() => {
    async function profile() {
      const data = await fetchProfileAPI();
      setUsers(data);
    }
    profile();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  const basicdetails = [
    { icon: <RiMessage2Fill />, text: users?.user.email },
    { icon: <FaPhoneAlt />, text: users?.user.mobile },
    { icon: <IoMdHome />, text: users?.user.address },
    { icon: <MdWork />, text: 'MPEOPLES' },
  ];

  return (
    <div className="profile-screen">
      <div>
        <div className="profile-header">
          <h2>Profile</h2>
        </div>

        <div className="profile-avatar-wrap">
          <div className="profile-avatar">
            <img
              // style={{ height: '90px', width: '90px' }}
              src={users?.user.profile_image}
              alt={users?.user.name}
            />
          </div>
        </div>

        <div className="profile-name">{users?.user.name}</div>
        <div className="profile-role">{users?.user.position}</div>
        <div className="profile-id">{users?.user.empid}</div>
      </div>

      <div className="section-label">BASIC DETAILS</div>
      <div className="info-card">
        {basicdetails.map((row, i) => (
          <div className="info-row" key={i}>
            <div className="info-icon">{row.icon}</div>
            <span>{row.text}</span>
          </div>
        ))}
      </div>

      <div className="section-label">SETTINGS</div>
      <div className="info-card">
        <div
          className="info-row"
          style={{ cursor: 'pointer' }}
          // onClick={handleLogout}
        >
          <div className="info-icon">
            <FaPhoneAlt />
          </div>
          <span>Change Password</span>
        </div>
        <div
          className="info-row"
          style={{ cursor: 'pointer' }}
          onClick={handleLogout}
        >
          <div className="info-icon">
            <IoMdHome />
          </div>
          <span>Logout</span>
        </div>
      </div>
      {/* Bottom nav — hidden on desktop via CSS */}
      <BottomNav />
    </div>
  );
}

export default ProfileScreen;
