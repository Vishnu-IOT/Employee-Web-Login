import axios from 'axios';

const BASE_URL = process.env.REACT_APP_BASE_URL;

// ──────────────────────────────────────────────
// Helper: Get auth headers with token
// ──────────────────────────────────────────────
// function getAuthHeaders() {
//   return {
//     headers: {
//       'ngrok-skip-browser-warning': 'true',
//     },
//   };
// }

// ========================================================
//    LOGIN SECTION
// ========================================================

async function loginAPI(cred) {
  try {
    const response = await axios.post(`${BASE_URL}/login`, cred);
    return response.data;
  } catch (err) {
    alert(err);
  }
}

async function fetchHomePageAPI() {
  try {
    const token = localStorage.getItem('token');

    const response = await axios.get(`${BASE_URL}/emp-homepagelist`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    return response.data;
  } catch (err) {
    console.error(err);
    alert(err.response?.data?.message || 'Something went wrong');
  }
}

async function fetchProfileAPI() {
  try {
    const token = localStorage.getItem('token');

    const response = await axios.get(`${BASE_URL}/profile`, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    return response.data;
  } catch (err) {
    console.error(err);
    alert(err.response?.data?.message || 'Something went wrong');
  }
}

async function fetchAttendanceWMAPI(wm) {
  try {
    const token = localStorage.getItem('token');

    const response = await axios.get(`${BASE_URL}/emp-attendance-WM`, {
      params: {
        wm: wm,
      },
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (err) {
    console.error(err);
    alert(err.response?.data?.message || 'Something went wrong');
  }
}

async function storeMarkAttendanceAPI(data) {
  try {
    const token = localStorage.getItem('token');

    const response = await axios.post(`${BASE_URL}/mark-attendance`, data, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (err) {
    console.error(err);
    alert(err.response?.data?.message || 'Something went wrong');
  }
}

export {
  loginAPI,
  fetchHomePageAPI,
  fetchProfileAPI,
  fetchAttendanceWMAPI,
  storeMarkAttendanceAPI,
};
